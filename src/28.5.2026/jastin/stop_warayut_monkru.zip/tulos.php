<?php

// if (isset($_GET['start']))
//     {
        $start = (int)$_GET['start'];
        $end = time();
        $secounds = $end - $start;
        // echo "ajastin on pysäytetty. kulunut aika: $secounds sekntia.";
        $minutes = floor($secounds / 60);
        $sec = $secounds % 60;
        echo " kulunut aika: $minutes minuuttia ja $sec sekuntia.";
<<<<<<< HEAD
    // }
    // else
    // {
    //     echo "Aloitusaika tai lopetusaika puuttuu.";
    // }
=======
    }
    else
    {
        echo "Aloitusaika tai lopetusaika puuttuu.";
    }
>>>>>>> aa94021f24b1d2952f10aa74af74fdcdc09082af
?>